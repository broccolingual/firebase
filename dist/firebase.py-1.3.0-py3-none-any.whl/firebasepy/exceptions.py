class TokenFileNotFoundError(Exception):
    "Firebase token file(json) is not found."